OFINE service
This application has not signed. You have to sign with this capabilities:

0x9e000 (NetworkServices+LocalServices+ReadUserData+WriteUserData+UserEnvironment)

After you have to install the application and the lightblue library. You can download from: http://lightblue.sourceforge.net

After installing this 2 applications you should put this files in your phone:

- ofine_contact.txt : Information to add in each message. Right now you should modify with the computer
- ofine_no.txt : Offers and needs saved in the system. There is another application that updates this file
- ofine_tags.txt : List of tags. Do not modify. Everyone have the same file.

(*) All the files should be in e:/Python/

One you have installed this files in your phone is important to know that your phone should have the identifier BT class of service:5898764. Nokia E51 and N95 have it. In the next version we will amplify the compatibility.


In the menu you can do 3 things:
	Switch on/off sending offers
	Switch on/of receiving offers
	See contact info

Right no is impossible to send and receive offers at the same time due to a look up service and ports, put we will solve in the next version.

So enjoy the app.
