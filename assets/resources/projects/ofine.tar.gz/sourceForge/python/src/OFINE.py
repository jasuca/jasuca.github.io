#!/usr/bin/env python
# encoding: utf-8
"""
OFINE.py

Created by jasuca on 2008-05-23.
Copyright (c) 2008 jasuca.com. All rights reserved.
"""
import os, sys

#To control the threads
import time
import thread

#For the BT
import lightblue
from lightblue import *

"""
Class Constant: Contains all the constants
"""
class Constant:
	SIM_VALUE = 0.5
	SCAN_TIME = 5
	HOST_CAD = 5
	
	OFINE_PORT = 5
	OFINE_LABEL = u"OFINE"
	CLASS_OF_SERVICE = 5898764 # N95 and E51
	
	TITLE_1 = u"Announcing offers"
	MENU_1 = [u"See announcement",u"Options", u"Start service", u"Stop service"]
	MESSAGES_1 = [u"Announcement started",u"Announcement stopped",u"Announcement has not started",u"Announcement has not stopped"]
	
	TITLE_2 = u"Recieving offers"
	MENU_2 = [u"See announcement",u"Options", u"Start service", u"Stop service"]
	MESSAGES_2 = [u"Announcement started",u"Announcement stopped",u"Announcement has not started",u"Announcement has not stopped"]

"""
Class OfineTag: Is an object tag
"""
class OfineTag:
	__id = 0
	__name = ""
	def __init__(self,ident,name):
		self.__id = ident
		self.__name = name
		pass
	def getId(self): return self.__id
	def getName(self): return self.__name
	def __cmp__(self, other):
		return self.__id.__cmp__(other.__id)
"""
Class OfineList: contains a list of offers/needs
"""
class OfineList:
	def __init__(self):
		self.__list = []
	
	def isEmpty(self):
		return len(self.__list)==0
	def add(self, ofine):
		if not ofine in self.__list:
			self.__list.append(ofine)
	def compare(self, offers):
		result = OfineList()
		for need in self.__list:
			for offer in offers.__list:
				sim = need.similarity(offer)
				if (sim>=Constant.SIM_VALUE):
					result.add(offer)
					#self.__writeMatching(offer, need, sim)
		return result
	
	def __writeMatching(self, offer, need, sim):
		print offer,"-",need, "(SIM:",sim,")"
		pass
	
	def getAsShortMessage(self):
		print "List:", len(self.__list)
		result = []
		for item in self.__list:
			#print "Elem:",
			#print item.getForShortMessage()
			result.append(item.getForShortMessage())
		
		return "\n\n".join(result)
	
	def getAsService(self):
		result = ["OFINE"]
		for item in self.__list:
			result.append(item.getForService())
		return ";".join(result)
	
	def setFromService(self, string):
		split = string.split(";")
		
		if (split[0] == "OFINE"):
			del split[0]
			#print "OFINE service"
			for item in split:
				ofine_it = OfineObject()
				ofine_it.setFromService(item)
				self.__list.append(ofine_it)
		else:
			print "Not OFINE service"

"""
Class OfineObject: Is a need or an offer. Has the comparator implemented
"""
class OfineObject:
	__id = 0
	__tags = []
	__name = ""
	__description = ""
	
	def __init__ (self, ident=-1, tags=[], name="", descrip=""):
		self.__id = ident
		self.__name = name
		self.__description = descrip
		self.__tags = tags
	def __cmp__(self, other):
		return cmp(self.__id,other.__id)
	def __str__(self):
		return ";".join([str(self.__id),str(self.__tags), str(self.__name), str(self.__description)])
	"""
	Return a number betwen 0-1 with the sim of the 2 objects.
	It's symetric. Iterate over the sortest tag list
	"""
	def similarity(self, otherOfine):
		
		m = 0
		notm = 0
		#Comparte the len of the 2 lists
		if len(otherOfine.__tags)>len(self.__tags):
			tagsSmall = self.__tags
			tagsBig = otherOfine.__tags
		else:
			tagsSmall = otherOfine.__tags
			tagsBig = self.__tags
		#Start comparing
		for item in tagsSmall:
			if item in tagsBig:
				tagsBig.index(item)
				m += 1
			else:
				notm += 1
		
		#print "Match(si, no):", matched, ",",notMatched
		
		noto = len(tagsBig) - m + notm
		sim = 1.0*m/(notm+noto+m)
		#print "INFO:", m, notm, noto, sim
		return sim
	
	def getId(self):
		return self.__id
	"""Return something like this: Name: xxxx \n Tags: xxxx"""
	def getForShortMessage(self):
		#print "Get as short message"
#		tags = ",".join(["%s" % el for el in self.__tags])
		tags = self.__translateTags()
		tagsString = ", ".join(tags)
		
		#print "Tgas translated"
		
		words = ["Description:"]
		words.append(self.__name)
		words.append("\n")
		words.append("Tags:")
		words.append(tagsString)
		
		return " ".join(words)
	def __translateTags(self):
		#print "Translating tags..."
		odb = OfineDataBase()
		dicTags = odb.readAllTags()
		#print "Tags:", dicTags
		tags = []
		for e in self.__tags:
			if (e in dicTags):
				tags.append(dicTags[e][0])
		return tags
	def getForService(self):
		tags = ":".join(["%s" % el for el in self.__tags])
		return ",".join([str(self.__id),tags,self.__name])
	def setFromService(self, string):
		split = string.split(",")
		self.__id = split[0]
		self.__name = split[2]
		self.__tags = split[1].split(":")
	
	def getForServiceBT(self):
		tags = ",".join(["%s" % el for el in self.__tags])
		return tags


"""
Class OfineDataBase
"""
class OfineDataBase:
	_sep = ";"
	_newln = "\n"
	_file_tag=u'E:\\Python\\ofine_tags.txt'
	_file_ofine=u'E:\\Python\\ofine_no.txt'
	_file_msg=u'E:\\Python\\ofine_msg.txt'
	_file_contact=u'E:\\Python\\ofine_contact.txt'
	_file_needs = 0
	_file_offers = 1
	
	
	def __init__(self):
		pass
	
	
	def __merge(self):
		# change the filename and directory of interest
		in_path=u'c:\\Data\\TextMTMService'
		#in_path=u'c:\\Python\\in'

		out_file = self._file_ofine 
		#u'c:\\python\\ofine_no.txt'

		dirList=os.listdir(in_path)

		#print dirList

		#clean the offer and need.
		file(out_file,'wb').write(u'')


		#merge the announces of offer and need to 
		#2 files.
		i = 0  
		for fname in dirList:
			#print fname
			i += 1
			if fname[0]=='m' :
				content = file(in_path+'\\'+fname,'r').read()
				content = content[:-3]
				lst_content = content.split(';')
				lst_content[0] = str(i)
				content2 = ';'.join(lst_content)
				content2 += ";"
				#print content2
				file(out_file,'ab').write(content2 + u'\n')




		pass
	
	def getContactInfo(self):
		contact = []
		fc = open(self._file_contact, 'r')
		
		#Add the contact information
		for line in fc:
			contact.append(line)
		
		fc.close()
		
		return "".join(contact)
	
	##Create a file with the message content and return the name file
	def createMsg(self, text):
		fc = open(self._file_contact, 'r')
		f = open(self._file_msg, 'w')
		
		#Add the contact information
		for line in fc:
			f.write(line)
		
		f.write("\n--------\n")
		
		#Add the matching informations
		f.write(text)
		
		
		fc.close()
		f.close()
		return self._file_msg
	
	#returns the dict of all categories or an empty dict
	#Remember that if it has the same id finaly its the last one
	def readAllTags(self):
		
		#print "Reading tags...(odb)"
		tags={}
		
		try:
			tag_file = open(self._file_tag,'r')
			
			for line in tag_file:
				tag = line.split(self._sep)
				#print "TGA:", tag
				tags[tag[0]]=[tag[1],tag[2]]
			
			tag_file.close()
		
		except Exception, e:
			self._exceptions(e)
		
		return tags
	
	#returns the category or an empty []
	def seekTag(self, id):
		category=[]
		
		try:
			tag_file = open(self._file_tag,'r')
			
			for line in tag_file:
				tag_line = line.split(self._sep)
				if tag_line[0]==id:
						category = tag_line
						break
				#print line
			tag_file.close()
		
		except Exception, e:
			self._exceptions(e)
		
		return category
	
	#Read Needs
	def readAllNeeds(self): return self._readAll(self._file_needs)
	def readAllOffers(self): return self._readAll(self._file_offers)
	def _readAll(self, of_type):
		#Merge the MTM files to one file
		self.__merge()
		
		
		elements=OfineList()
		
		try:
			file_elements = open(self._file_ofine,'r')
			
			for line in file_elements:
				#announce_id(integer);type(0/1);tag_id(integer),tag_id(integer),...\n
				element = line.split(self._sep)
				of_id = element[0]
				of_ty = element[1]
				of_tgs = element[2].split(",")
				of_name = element[3]
				of_desc = element[4]
				
				
				if (str(of_type)==of_ty):
					
					o1 = OfineObject(of_id,of_tgs,of_name, of_desc)
					elements.add(o1)
			
			file_elements.close()
		
		except Exception, e:
			self._exceptions(e)
		
		return elements
		
		
		
	
	#Exceptions
	def _exceptions(self, exception):
		raise exception
		#pass
		
		

"""
Class AnnounceOffers: read the file and announce the offers to the bt services.
IT'S THE MAIN FOR THE OFFERS
"""

class AnnounceOffers(object):
	def __init__ (self):
		self.output = ""
		self.offers = ""
		self.known_hosts = []
		
		
		self.active = True
		self.lock = thread.allocate_lock()
		self.DeviceList = list()
		self.startAnnouncing()

	
	def startAnnouncing(self):
		thread.start_new_thread(self.announce, ())
	
	def announce(self):
		print "Anouncing thread activated"
		
		#Time to 0
		
		#Start iteration
		timeHost = 0
		i = 0
		while self.active:
			#Read and generate the offers
			self.output = str(i)+";"
			i += 1
			self.offers = self.__getOffers()
			self.output += self.offers
			
			#Search for all OFINE neighbours and send the offers
			self.__announceOnce()
			
			#Time to known hosts
			timeHost += 1
			if timeHost > Constant.HOST_CAD:
				self.known_hosts = []
				timeHost = 0
			
			#wait some time to change the advertisment
			time.sleep(Constant.SCAN_TIME)
		
		print "Stop and close socket"
	
	def __announceOnce(self):
		#Look up arround
		neighbours = self.__obtainNeighbours()
		
		for ngb in neighbours:
			#Did we look at him n times before
			if not ngb in self.known_hosts:
				#Add to the list
				self.known_hosts.append(ngb)
				#someone have a service RFCOMM called OFINE
				if self.__haveOfineService(ngb):
					#Iterate over the ofine services
					#print "Is ofine", ngb
					#send the offers file
					self.__sendOffers(ngb, Constant.OFINE_PORT, self.offers)
					time.sleep(2)
		pass
	
	
	def __sendOffers(self, addr, port, offers):
		print "Sending offerts on port", port
		try:
			#offers = "hola"
			
			self.socket = lightblue.socket()
			self.socket.connect((addr, port))
			self.socket.send(offers)
			
			time.sleep(2)
			
			self.socket.close()
		
		except Exception, e:
			print e

	def __obtainNeighbours2(self):
		print "looking devices... (pro activated)"

		N73 = "00:1D:6E:BF:52:7A"
		E51 = ""
		N95 = "00:18:42:EB:AF:26"
		returnDevices = [N73]#, N95]

		##That's the working one. But sine we have problems with bt discover, we return a
		##fix number of MAC address
		"""
		devices = lightblue.finddevices(False)

		returnDevices = []
		for device in devices:
			if device[2] == Constant.CLASS_OF_SERVICE:
				#print device
				returnDevices.append(device[0])
		"""
		print "found: ", returnDevices
		return returnDevices
			
	def __obtainNeighbours(self):
		print "looking devices..."
	
		devices = lightblue.finddevices(False)
		
		returnDevices = []
		for device in devices:
			if device[2] == Constant.CLASS_OF_SERVICE:
				#print device
				returnDevices.append(device[0])

		print "found: ", returnDevices
		return returnDevices

	def __haveOfineService(self, addr):

		return True
		##That's the working one. But sine we have problems with bt discover, we return a
		##fix number of MAC address
				
	def __haveOfineService2(self, addr):
		
		offers = []
		
		print "Searching services from", addr
		try:
			services = lightblue.findservices(addr,None,lightblue.OBEX)
		except Exception, e:
			print "Impossible to get services"
			return false
		print services
		
		have_service = False
		for service in services:
			have_service = have_service or (Constant.OFINE_LABEL in service)
			if have_service: break
		return have_service	
	
	def stopAnnouncing(self):
		self.active = False
	
	
	def __openSocket(self):
		# Create a bluetooth socket in waiting state to be connected to
		#s = socket(AF_BT, SOCK_STREAM)
		self.socket = lightblue.socket()
		
		port = Constant.OFINE_PORT
		#port = bt_rfcomm_get_available_server_channel(s)
		print "Binding service to port %s"%port
		self.socket.bind(("", port))
		print "Service bound."
	
	def __getOffers(self):
		#read the offers from a file
		odb = OfineDataBase()
		offers = odb.readAllOffers()
		adverticeService = offers.getAsService()
		return adverticeService

"""
Class AnnounceOffers: read the file and announce the offers to the bt services.
IT'S THE MAIN FOR THE OFFERS
"""

class RecieveOffers(object):
	def __init__ (self):
		
		odb = OfineDataBase()
		self.__needs = odb.readAllNeeds()
		
		self.output = ""
		
		self.active = True
		self.lock = thread.allocate_lock()
		self.DeviceList = list()
		self.startWaiting()

	
	def startWaiting(self):
		thread.start_new_thread(self.waitAnnounce, ())
	
	def waitAnnounce(self):
		print "Waiting thread activated"
		
		#Open the socket
		self.__openSocket()
		
		#While acceptiong connections
		
		while self.active:
			
			try:
				#Wait for the connection
				conn, addr = self.socket.accept()
				print "Connected by", addr
				
				#Maybe a while to recieve lot of data
				data =  conn.recv(1024)
				print data
				
				#Extract the data and do the matching
				try:
					print "Received:" , data
					shortMessage, isEmpty = self.__manufactureData(data)
					print "Short message:", shortMessage
					#To know wat u are sending
					if not isEmpty:
						self.output = shortMessage
						self.__sendShortMessage(addr[0], shortMessage)
				except Exception, e:
					print e
				
				time.sleep(2)
				
				conn.close()
			except Exception, e:
				print e
				self.__closeSocket()
				self.__openSocket()
		
		##self.__closeSocket()
	
	def __openSocket(self):
		print "Start listening on RFCOM, ", Constant.OFINE_PORT
		self.socket = lightblue.socket()
		self.socket.bind(("", Constant.OFINE_PORT))  # bind to 0 to bind to dynamically assigned port
		self.socket.listen(5)
		lightblue.advertise("OFINE rfcom", self.socket, lightblue.RFCOMM)
		pass
	
	def __closeSocket(self):
		self.socket.close()
		print "Stop and close socket"
		pass
	
	def stopWaiting(self):
		self.active = False
		self.__closeSocket()
		pass

	
	def __manufactureData(self, dataOffers):
		
		offers = self.__translateOffers(dataOffers)
		#print offers.getAsService()
		#Make the mactching
		print "Making matching..."
		matching = self.__makeMatching(offers)
		isEmpty = matching.isEmpty()
		if not isEmpty:
			print "Matching not empty"
			return matching.getAsShortMessage(), isEmpty
		else:
			print "Matching empty"
			return "", isEmpty

	
	def __translateOffers(self, offers):
		returnoff = OfineList()
		returnoff.setFromService(offers)
		return returnoff
	
	def __makeMatching(self, offers):
		match = self.__needs.compare(offers)
		return match
	def __sendShortMessage(self, addr, msg):
		odb = OfineDataBase()
		filename = odb.createMsg(msg)
		lightblue.obex.sendfile(addr, 9, filename)
		pass

