#!/usr/bin/env python
# encoding: utf-8
"""
OFINE interface.py

Created by jasuca on 2008-05-25.
Copyright (c) 2008 jasuca.com. All rights reserved.
"""

# import the application user interface framework module
import sys, appuifw, e32, graphics, key_codes
from graphics import Image

#Other modules

__exec_path = "E:\\Python\\"
sys.path.append(__exec_path)

from OFINE import *


def convertUnicode(list_string):
	return [unicode(x) for x in list_string]

MESSAGES_s = ["Sending on", "Sending off","Sending already on", "Sending already off","Stop receiving before", "Sending is off"]
MESSAGES_r = [ "Receiving on", "Receiving off","Receiving already on", "Receiving already off","Stop sending before", "Receiving is off"]
MESSAGES = [convertUnicode(MESSAGES_s), convertUnicode(MESSAGES_r)]


MENU_s = ["Send offers", "Info", "On", "Off"]
MENU_r = ["Receive offers", "Last message send", "On", "Off"]
MENU = [convertUnicode(MENU_s), convertUnicode(MENU_r), u"Contact", u"Debug"]


TITLE = u"OFINE service"


#MAIN GENERAL

#Window size
appuifw.app.screen='full'

#Start running
#0 - all stoped
#1 - sending offers
#2 - recieving offers
running=0

#Debuging: show console
debug = False


#The bg
bg = graphics.Image.open('e:\\python\\bg_0.jpg')
bg_s = graphics.Image.open('e:\\python\\bg_1.jpg')
bg_r = graphics.Image.open('e:\\python\\bg_2.jpg')

def handle_redraw(rect):
	global running
	if running == 0:
		canvas.blit(bg)
	elif running == 1:
		canvas.blit(bg_s)
	else:
		canvas.blit(bg_r)
	
canvas = appuifw.Canvas(redraw_callback=handle_redraw)
appuifw.app.body = canvas

canvas.blit(bg)



#execute the announcing
r_current = None #RecieveOffers()
#execute the announcing
s_current = None #AnnounceOffers()
#Contact info
odb = OfineDataBase()
contact = odb.getContactInfo()
contact = unicode(contact)


#MENU options
def sendOffersShow():
	global running
	if running == 1:
		#Get the text of OFINE
		global current
		text =  s_current.output
		appuifw.note(unicode(text), "info")
	else:
		appuifw.note(MESSAGES[0][5], "info")

def sendOffersStart():
	global running
	if running==1:
		appuifw.note(MESSAGES[0][2], "info")
	elif running==2:
		appuifw.note(MESSAGES[0][4], "info")
	else:
		running=1
		appuifw.app.menu = MENU_1
		global s_current
		s_current = AnnounceOffers()
		appuifw.note(MESSAGES[0][0], "info")

def sendOffersStop():
	global running
	if running == 1:
		running=0
		appuifw.app.menu = MENU_0
		global s_current
		s_current.stopAnnouncing()
		del s_current
		appuifw.note(MESSAGES[0][1], "info")
	else:
		appuifw.note(MESSAGES[0][3], "info")

def recvOffersShow():
	global running
	if running == 2:
		#Get the message send
		global r_current
		text =  r_current.output
		appuifw.note(unicode(text), "info")
	else:
		appuifw.note(MESSAGES[1][5], "info")

def recvOffersStart():
	global running
	if running==2:
		appuifw.note(MESSAGES[1][2], "info")
	elif running==1:
		appuifw.note(MESSAGES[1][4], "info")
	else:
		running=2
		appuifw.app.menu = MENU_2
		global r_current
		r_current = RecieveOffers()
		
		appuifw.note(MESSAGES[1][0], "info")

def recvOffersStop():
	global running
	if running == 2:
		running=0
		appuifw.app.menu = MENU_0
		global r_current
		r_current.stopWaiting()
		del r_current
		appuifw.note(MESSAGES[1][1], "info")
	else:
		appuifw.note(MESSAGES[1][3], "info")
def information():
	#Obtain the contact information
	global contact
	appuifw.note(contact, "info")
	
#Good idea to implement a function that removes the image and show the shell
def debug():
	global debug
	if debug:
		debug = False
		#Enable
		appuifw.app.body = canvas
	else:
		debug = True
		#disble canavas
		appuifw.app.body = None

#POSSIBLE MENUS
s_MENU_ON = (MENU[0][0], ((MENU[0][2], sendOffersStart),(MENU[0][1], sendOffersShow)))
s_MENU_OFF = (MENU[0][0], ((MENU[0][3], sendOffersStop),(MENU[0][1], sendOffersShow)))
r_MENU_ON = (MENU[1][0], ((MENU[1][2], recvOffersStart),(MENU[0][1], sendOffersShow)))
r_MENU_OFF = (MENU[1][0], ((MENU[1][3], recvOffersStop),(MENU[1][1], recvOffersShow)))
MENU_INFO = (MENU[2], information)
MENU_DEBUG = (MENU[3], debug)

MENU_0 = [s_MENU_ON, r_MENU_ON, MENU_INFO]
MENU_1 = [s_MENU_OFF, MENU_INFO]
MENU_2 = [r_MENU_OFF, MENU_INFO]
appuifw.app.menu = MENU_0


def exit_key_handler():
	global running
	if running == 1:
		sendOffersStop()
	elif running == 2:
		recvOffersStop()
		
	app_lock.signal()

# The title
appuifw.app.title = TITLE

app_lock = e32.Ao_lock()

appuifw.app.exit_key_handler = exit_key_handler
app_lock.wait()


