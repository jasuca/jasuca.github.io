OFINE service
This application needs this files:

OFINEui.py : The main application. Is the script to run
OFINE.py : All the classes needed to work
bg_0.jpg, bg_1.jpg, bg_2.jpg : Images for the UI
ofine_contact.txt : Information to add in each message. Right now you should modify with the computer
ofine_no.txt : Offers and needs saved in the system. There is another application that updates this file
ofine_tags.txt : List of tags. Do not modify. Everyone have the same file.

(*) All the files should be in e:/Python

One you have installed this files in your phone is important to know that your phone should have the identifier BT class of service:5898764. Nokia E51 and N95 have it. In the next version we will amplify the compatibility.

In the menu you can do 3 things:
	Switch on/off sending offers
	Switch on/of receiving offers
	See contact info

Right no is impossible to send and receive offers at the same time due to a look up service and ports, put we will solve in the next version.

So enjoy the app.
