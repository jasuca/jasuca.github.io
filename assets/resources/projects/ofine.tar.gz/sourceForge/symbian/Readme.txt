Ofine MTM interface.

The installation is like other Symbian application. 
After Ofine MTM is installed at the first time, we have to run Txinstall to activate it.
If we run Txdeinstall, the Ofine MTM is deactivated and all message created by Ofine is deleted.

Ofine MTM reads the tags from the file C:\data\ofine_tags.txt, 
so after Ofine MTM is installed, we have to copy the same tag file used by OFINE service to C:\data.

After everything is done, we can send the Ofine announcement as the normal SMS.

Ofine MTM is modified from the MTM example. Most of the mofication is done in Viewer, and I add TxtViewerList.cpp, TxtViewerList.h, TagTable.cpp, TagTable.h.
I have commented out some other modifications by "// modification".