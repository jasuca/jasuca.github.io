/*
* ============================================================================
*  Name     : CTxtViewerService from MuiuMsgEditorService.h
*  Part of  : msgavkon\muiu
*
*  Description:
*     Client-side service implementations
*
*  Version:
*
*  Copyright (C) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing,  adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
*
* ============================================================================
*/

#ifndef MUIUMSGEDITORSERVICE_H
#define MUIUMSGEDITORSERVICE_H

#include <f32file.h>
//#include <EikServerApp.h>
//#include <ApaServerApp.h>
#include <AknServerApp.h>
#include <ApaServerApp.h>

#include <MsvApi.h>
#include "TxtViewerStarter.h"
//#include <MuiuMsgEditorServiceConst.h>



// Lower level client side service class

class RTxtViewerService : public RAknAppServiceBase
	{
	public: 
		/**
		* Sends command EMuiuMsgEditorServiceCmdOpen to the server side
		* with parameters aParams (excluding iSpecialAppId)
		*/
		void OpenEntryL( const TEditorParameters aParams );
		
	private: // From RApaAppServiceBase
		/**
		* Returns the uid of the service
		*/
		TUid ServiceUid() const;
	};

#endif