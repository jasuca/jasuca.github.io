// txtipan.h
//
// � 2004 Nokia Corporation.  All rights reserved.
//

#if !defined(__TXTIPAN_H__)
#define __TXTIPAN_H__

//
//	TTxtiMtmUdPanic: MTM panics
//

enum TTxtiMtmUdPanic
	{
	ETxtiMtmUdWrongMtm,
	ETxtiMtmUdFoldersNotSupported,
	ETxtiMtmUdAttachmentsNotSupported,
	ETxtiMtmUdNoIconForAttachment,
	ETxtiMtmUdRootEntryGiven,
	ETxtiMtmUdUnknownOperationId
	};

GLREF_C void Panic(TTxtiMtmUdPanic aPanic);

#endif
