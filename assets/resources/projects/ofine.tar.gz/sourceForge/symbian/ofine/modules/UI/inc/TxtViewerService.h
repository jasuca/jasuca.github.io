

#ifndef MTXTSERVICE_H
#define MTXTSERVICE_H


#include <AknServerApp.h>
#include <ApaServerApp.h>

#include <MsvApi.h>

class TEditorParameters
{
	public:
	TInt iEntry;
	TBool iOpenedForEditing;
	
};



// client side API class

class RTxtViewerService : public RAknAppServiceBase
	{
	public: 
		/**
		* Sends a command to the server
		*
		*/
		void OpenL(TEditorParameters aParams);
		
	private: // From RApaAppServiceBase
		/**
		* Returns the uid of the service this is here for the framework
		*/
		TUid ServiceUid() const;
	};

#endif
