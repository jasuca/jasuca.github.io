#ifndef TAGTABLE_H_
#define TAGTABLE_H_

// INCLUDES
#include <eikedwin.h> 
#include "EIKRTED.H"
#include <TXTCMDS.HRH>
#include <coecntrl.h>
#include <MSVSTD.H>
#include <msvapi.h>
#include <aknlists.h>

// this structure keeps the information for one tag.
struct TagStruct
	{
	HBufC8 *name;
	HBufC8 *id;
	~TagStruct()
		{
		delete name;
		delete id;
		}
	};

// this class keeps all the information I need about tags.
class TTagTable
{
private:
	CArrayFixFlat<TagStruct *> *iTagTable;
	TTagTable(TInt size);
public:
	~TTagTable();
	static TTagTable *CreateTagTableL(const TDes &filename , TInt size);
	static TTagTable *CreateDummyTagTableL();
	TagStruct *GetTagByPos(const TInt );
	TagStruct *GetTagByID(const TBuf8<16> &);
	TagStruct *GetTagByName(const TBuf8<32> &);
	TInt GetIdx(const TagStruct *tag);
};

#endif /*TAGTABLE_H_*/
