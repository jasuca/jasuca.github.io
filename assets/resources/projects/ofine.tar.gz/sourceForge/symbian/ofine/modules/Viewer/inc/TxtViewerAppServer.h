

#ifndef TXTVIEWERAPPSERVER_H
#define TXTVIEWERAPPSERVER_H

// INCLUDES

#include <AknServerApp.h>


class CTxtViewerAppServer : public CAknAppServer
    {
    public: // from CAknAppServer
    CApaAppServiceBase* CreateServiceL( TUid aServiceType ) const;
    protected: // from CPolicyServer
	virtual TCustomResult CustomFailureActionL(
							const RMessage2& aMsg,
							TInt aAction,
							const TSecurityInfo& aMissing );
    };

#endif     //TXTVIEWERAPPSERVER_H

// End of File
