

#ifndef __TXTVIEWVERAPPVIEW_H__
#define __TXTVIEWVERAPPVIEW_H__

// INCLUDES
#include <eikedwin.h> 
#include "EIKRTED.H"
#include <TXTCMDS.HRH>
#include <coecntrl.h>
#include <MSVSTD.H>
#include <msvapi.h>
#include <aknlists.h>

#include "TxtViewerList.h"
#include "TagTable.h"

class CTextMtmClient; 
class CTextMtmUi; 

class CMsvSession;
class CMsvStore;
class CEikRichTextEditor;
class CClientMtmRegistry;
class CMtmUiRegistry;
class CMsvOperation;
class CMsvEntrySelection;
// CLASS DECLARATION
class TDummyObserver : public MMsvSessionObserver
	{
public:
	void HandleSessionEventL(TMsvSessionEvent /*aEvent*/, TAny* /*aArg1*/, TAny* /*aArg2*/, TAny* /*aArg3*/) {};
	};

#define BUF_SIZE 256

class CTxtViewerAppView : public CCoeControl
    {
    public: // New methods
		TRequestStatus* it;
		CMsvOperation* iop;
		CMsvEntrySelection* iselection;
		
		TBuf8<1> iscrap;
        
        //Loads body from the store to the editor
        void LoadBodyL();

        //Saves body from the editor to the store
        void SaveBodyL();

        void ExportToFileL( const TDes& aFileName );

		CTextMtmUi* UiMtm() 
		{
			return iUiMtm;
		}
		
		CTextMtmClient *ClientMtm()
		{
			return iClientMtm;
		}
		
		TMsvId EntryId();

		TBool OpenedForEditing();
		
		void Notify();
		
        /**
        * NewL.
        * Two-phased constructor.
        * Create a CTxtViewerAppView object, which will draw itself to aRect.
        * @param aRect The rectangle this view will be drawn to.
        * @return a pointer to the created instance of CTxtViewerAppView.
        */
        static CTxtViewerAppView* NewL( const TRect& aRect );

        /**
        * NewLC.
        * Two-phased constructor.
        * Create a CTxtViewerAppView object, which will draw itself
        * to aRect.
        * @param aRect Rectangle this view will be drawn to.
        * @return A pointer to the created instance of CTxtViewerAppView.
        */
        static CTxtViewerAppView* NewLC( const TRect& aRect );

        /**
        * ~CTxtViewerAppView
        * Virtual Destructor.
        */
        virtual ~CTxtViewerAppView();

    public:  // Functions from base classes
    	void InitializeMTMsL();
    	TInt CountComponentControls() const;
    	CCoeControl* ComponentControl( TInt aIndex ) const;
        
        /**
        * From CCoeControl, Draw
        * Draw this CTxtViewerAppView to the screen.
        * @param aRect the rectangle of this view that needs updating
        */
        void Draw( const TRect& aRect ) const;
        
        /**
        * From CoeControl, SizeChanged.
        * Called by framework when the view size is changed.
        */
        virtual void SizeChanged();

	   TKeyResponse OfferKeyEventL(const TKeyEvent &aKeyEvent, TEventCode aType);

	   void GetSelectedTagItemsL(int ok);
	   void GetSelectedTypeItemL();
	   
	   int MoveFocusControl(const TKeyEvent& aKeyEvent , TEventCode aType);
	   void SetTypeText(int pos);
	   void SetTagsText(const CArrayFix<TInt> *indexes , TDes8 *retTagsIDs);
	   
	   TInt CreateTagsL(const TDes &filename);
	   
	   bool CloseSelectionList();

    private: // Constructors

        /**
        * ConstructL
        * 2nd phase constructor.
        * Perform the second phase construction of a
        * CTxtViewerAppView object.
        * @param aRect The rectangle this view will be drawn to.
        */
        void ConstructL(const TRect& aRect);

        /**
        * CTxtViewerAppView.
        * C++ default constructor.
        */
        CTxtViewerAppView();
        
      
        void InitializeControlsL(const TRect& aRect);
        
        

	private:
		CMsvSession* iSession;
		CMsvStore* iStore;
		
		CEikLabel* iTypeLabel;
		CEikLabel* iTagLabel;
		CEikEdwin* iTypeText;
		CEikEdwin* iTagsText;
		CEikRichTextEditor* iEditor;
//		CEikGlobalTextEditor* iEditor;
		
		CTxtViewerTypeList* iTypeListBox;
		CTxtViewerTagsList* iTagsListBox;
		
		TBuf8 <BUF_SIZE> iTagIDs;
		int iMsgType;
		
	public:
		TTagTable *iTagTable;

#define FOCUSCONTROLNUM 3
		CCoeControl *iFocusControls[FOCUSCONTROLNUM];
		int iCurrentFocusIdx;

		HBufC* iText;
		CTextMtmClient* iClientMtm; 
		CTextMtmUi* iUiMtm; 
		CClientMtmRegistry* iClientReg;
		CMtmUiRegistry* iUiReg;

		TDummyObserver iOb;

		enum TControls
			{
			// [[[ begin generated region: do not modify [Generated Contents]
//			ETypeListBox,
			ETypeLabel,
			ETagLabel,
			ETypeText,
			ETagsText,
			EDescriptionText,
			
			// ]]] end generated region [Generated Contents]
			
			// add any user-defined entries here...
			
			ELastControl
			};

    };
    
#endif // __TXTVIEWVERAPPVIEW_H__

// End of File

