

#ifndef     TXTVIEWERDOCUMENT_H
#define     TXTVIEWERDOCUMENT_H

//  INCLUDES

#include "akndoc.h"
#include <MSVSTD.H>

class CTxtViewerAppView;

// CLASS DECLARATION

/**
*  CMsgSmsviewerDocument
*/
class CTxtViewerDocument : public CEikDocument
    {
    public:  // Constructors and destructor
        
        /**
        * Two-phased constructor.
        */
        static CTxtViewerDocument* NewL(CEikApplication& aApp);  
        
        /**
        * Destructor.
        */
        virtual ~CTxtViewerDocument();
        
        void InitializeL(); 
        void SetView(CTxtViewerAppView* aView); 
        
      
		void SetId(TMsvId aId);
		TMsvId Id();


		void SetOpenedForEditing(TBool aOpenedForEditing);
		TBool OpenedForEditing();
	
	
		
		void SetMessage(const RMessage2 aMessage);
		RMessage2 Message();


    public:

    private: // Functions from base classes

     
    private:

        /**
        * C++ constructor.
        */
        CTxtViewerDocument(CEikApplication& aApp);

        /**
        * Creates a new CTxtViewerAppUi
        * @param none
        * @return a pointer to CTxtViewerAppUi
        */
        CEikAppUi* CreateAppUiL();
        
        
         /**
        * ConstructL
        * 2nd phase constructor.
        */
        void ConstructL();

	private:
	
		TMsvId iId;
		TBool iOpenedForEditing;
		TBool iSend;
		RMessage2 iMessage;
		CTxtViewerAppView* iAppView;

    };

#endif      //  TXTVIEWERDOCUMENT_H
            
// End of File
