#ifndef TXTVIEWERLIST_H_
#define TXTVIEWERLIST_H_

// INCLUDES
#include <eikedwin.h> 
#include "EIKRTED.H"
#include <TXTCMDS.HRH>
#include <coecntrl.h>
#include <MSVSTD.H>
#include <msvapi.h>
#include <aknlists.h>

struct TagStruct;
class CTxtViewerAppView;

// this class is for type selection list box(which is single selection).
class CTxtViewerTypeList : public CCoeControl, public MEikListBoxObserver
	{
public:
	static CTxtViewerTypeList* NewL(const TRect& aRect , CCoeControl *father);
	~CTxtViewerTypeList();
public:
	//	from CCoeControl
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);
public:
	// from MEikListBoxObserver 
	void HandleListBoxEventL(CEikListBox* aListBox, TListBoxEvent aEventType);
protected:
	//  From CCoeControl
	void SizeChanged();
	TInt CountComponentControls() const;
	CCoeControl* ComponentControl(TInt aIndex) const;
private:
	void SetupListTextL();
	CTxtViewerTypeList(CCoeControl *father);
	void ConstructL(const TRect& aRect);
	void Draw(const TRect& aRect) const;
private:
	CAknColumnListBox* iListBox;
	CCoeControl *iFather;
	RArray<TInt> iFocusPos; // position of focus in listbox for the folders passed, used whem going back
public:
	TInt iCurrPos; // index in current folder/listbox 
	
public:
	enum Type{
	ENEED=0,
	EOFFER
	};
	};

// this class is for tag selection list box(which is multiple selection).
class CTxtViewerTagsList : public CCoeControl, public MEikListBoxObserver
	{
public:
	static CTxtViewerTagsList* NewL(const TRect& aRect, CCoeControl *father);
	~CTxtViewerTagsList();
public:
	//	from CCoeControl
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);
public:
	// from MEikListBoxObserver 
	void HandleListBoxEventL(CEikListBox* aListBox, TListBoxEvent aEventType);
	const CArrayFix<TInt> *GetSelectedItemsL();
protected:
	//  From CCoeControl
	void SizeChanged();
	TInt CountComponentControls() const;
	CCoeControl* ComponentControl(TInt aIndex) const;
private:
	void SetupListIconsL();
	void SetupListTextL();
	//	void NavigateL(TInt aIndex);
private:
	CTxtViewerTagsList(CCoeControl *father);
	void ConstructL(const TRect& aRect);
private:
	void Draw(const TRect& aRect) const;
private:
	CAknColumnListBox* iListBox;
	CCoeControl *iFather;
	RArray<TInt> iFocusPos; // position of focus in listbox for the folders passed, used whem going back
private:
	TInt iCurrPos; // index in current folder/listbox 
	};

#endif /*TXTVIEWERLIST_H_*/
