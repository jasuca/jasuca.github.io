#ifndef UTIL_H_
#define UTIL_H_

#include <eikedwin.h> 
#include "EIKRTED.H"
#include <TXTCMDS.HRH>
#include <coecntrl.h>
#include <MSVSTD.H>
#include <msvapi.h>
#include <aknlists.h>

int strlen(const char *str);

#endif /*UTIL_H_*/
