// INCLUDE FILES
#include <coemain.h>
#include <EIKENV.H> 

#include <eikdef.h>
#include <coeaui.h>
#include "txtviewerdoc.h"
#include "EIKAPPUI.H"
#include <aknutils.h> //LayoutUtils

#include <eiktxlbx.h> 
#include <akniconarray.h> 
#include <gulicon.h>
#include <eikclbd.h>
#include <avkon.mbg>
#include <stringloader.h>

//Messaging related

#include <mtclreg.h>
#include <mtuireg.h>
#include <MTUDREG.H> 
#include <MTUIREG.H> 
#include <msvids.h>
#include <TXTRICH.H>
#include <eiklabel.h>
#include <BARSREAD.H>
#include <stringloader.h> 
#include <TxtViewer.RSG>
#include <flogger.h>
#include <VERSIT.H>

#include <MTCLBASE.H> // SwitchCurrentEntryL

#include "TagTable.h"
#include "util.h"

static void writeLog(TRefByValue<const TDesC16> aFmt,...)
	{
#define KMaxFileName 128
	VA_LIST list;
	VA_START(list,aFmt);

	TBuf<KMaxFileName> buf;
	buf.AppendFormatList(aFmt,list);
	VA_END(list);

	RFileLogger::Write(_L ("log"), _L ("testlog"), EFileLoggingModeAppend, buf);
	}

TTagTable::TTagTable(TInt size)
	{
	iTagTable=new CArrayFixFlat<TagStruct *>(size);
	}

TTagTable::~TTagTable()
	{
	for (int i=0; i < iTagTable->Count (); i++)
		{
		delete iTagTable->At(i);
		}
	delete iTagTable;
	}

// this function creates a dummy tag table.
// only used for testing.
TTagTable *TTagTable::CreateDummyTagTableL()
	{
	char *ids[]=
		{
				"0000", "0001", "0002"
		};
	char *names[]=
		{
				"Computer", "Book", "Ticket"
		};

	TTagTable *table=new TTagTable(3);
	CleanupStack::PushL (table);
	for (int i=0; i < 3; i++)
		{
		TagStruct *tag=new TagStruct;
		CleanupStack::PushL (tag);
		HBufC8* id=HBufC8::NewLC(strlen(ids[i]));
		*id=(const TUint8 *)ids[i];
		HBufC8* name=HBufC8::NewLC(strlen(names[i]));
		*name=(const TUint8 *)names[i];
		tag->id=id;
		tag->name=name;
		table->iTagTable->AppendL (tag);
		CleanupStack::Pop (3);
		}
	CleanupStack::Pop (table);
	return table;

	}

// this function read the tags from the tag file,
// and creates the tag table.
TTagTable *TTagTable::CreateTagTableL(const TDes &filename , TInt size)
	{
	RFileReadStream myFileReadStream;

	if ( myFileReadStream.Open ( CCoeEnv::Static()->FsSession (), filename, EFileRead)!= KErrNone){
		writeLog(filename);
		writeLog(_L("cannot open the tag file"));
		return NULL;
	}
	CLineReader *reader=CLineReader::NewL (myFileReadStream);
	CleanupStack::PushL (reader);
	TTagTable *table=new TTagTable(size);
	CleanupStack::PushL (table);
	TInt err;
	
	for (int i=0; i < size; i++)
		{
		reader->ReadLineL (0, err);
		if ( err == KErrEof)
			break;
		TInt len=reader->iBufPtr.FindC ((const unsigned char *)";", 1);
		if ( len == KErrNotFound)
			{
			CleanupStack::PopAndDestroy ();
			myFileReadStream.Close();
			return NULL;
			}
		TagStruct *tag=new TagStruct;
		CleanupStack::PushL (tag);
		HBufC8* id=HBufC8::NewLC(len);
		*id=reader->iBufPtr.MidTPtr (0, len);
		HBufC8* name=HBufC8::NewLC(reader->iBufPtr.Length ()-1-len-1);
		*name=reader->iBufPtr.MidTPtr (len+1,
				reader->iBufPtr.Length ()-1-len-1);
		tag->id=id;
		tag->name=name;
		table->iTagTable->AppendL (tag);
		CleanupStack::Pop (3);
		}

	CleanupStack::Pop (table);
	CleanupStack::PopAndDestroy (reader);
	myFileReadStream.Close();
	return table;
	}

TagStruct *TTagTable::GetTagByPos(const TInt pos)
	{
	if ( pos >= iTagTable->Count ())
		return NULL;
	return iTagTable->At (pos);
	}

TagStruct *TTagTable::GetTagByID(const TBuf8<16> &id)
	{
	for (int i=0; i < iTagTable->Count (); i++)
		{
		if ( iTagTable->At(i)->id->Compare (id)== 0)
			return iTagTable->At (i);
		}
	writeLog(_L("cannot find the tag"));
	return NULL;
	}

TagStruct *TTagTable::GetTagByName(const TBuf8<32> &name)
	{
	for (int i=0; i < iTagTable->Count (); i++)
		{
		if ( iTagTable->At(i)->name->Compare (name)== 0)
			return iTagTable->At (i);
		}
	return NULL;

	}

TInt TTagTable::GetIdx(const TagStruct *tag)
{
	for(int i=0 ; i < iTagTable->Count() ; i++)
		{
		if(iTagTable->At(i) == tag)
			return i;
		}
	return -1;
}