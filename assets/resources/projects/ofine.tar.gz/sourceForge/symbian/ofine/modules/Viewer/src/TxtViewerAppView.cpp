

// INCLUDE FILES
#include <coemain.h>
#include <EIKENV.H> 

#include <eikdef.h>
#include <coeaui.h>
#include "txtviewerdoc.h"
#include "EIKAPPUI.H"
#include <aknutils.h> //LayoutUtils
#include <eiktxlbx.h> 
#include <akniconarray.h> 
#include <gulicon.h>
#include <eikclbd.h>
#include <avkon.mbg>
#include <stringloader.h>

//Messaging related

#include <mtclreg.h>
#include <mtuireg.h>
#include <MTUDREG.H> 
#include <MTUIREG.H> 
#include <msvids.h>
#include <TXTRICH.H>
#include <eiklabel.h>
#include <BARSREAD.H>
#include <stringloader.h> 
#include <TxtViewer.RSG>
#include <flogger.h>
#include <VERSIT.H>

#include <MTCLBASE.H> // SwitchCurrentEntryL


#include "TxtViewerAppView.h"
#include "TxtViewerAppUi.h"
#include "../../Client/inc/txclient.h"
#include "../../UI/inc/txtu.h"

const TInt KNumberOfLines = 5;
const TInt KTextLimit = 100;

#define MAX_TAGS 10
#define MAX_TAG_TABLE 128

_LIT(KTextMTMTagsFile ,  "C:\\data\\ofine_tags.txt");

static void writeLog(TRefByValue<const TDesC16> aFmt,...)
	{
#define KMaxFileName 128
	VA_LIST list;
	VA_START(list,aFmt);

	TBuf<KMaxFileName> buf;
	buf.AppendFormatList(aFmt,list);
	VA_END(list);

	RFileLogger::Write(_L ("log"), _L ("testlog"), EFileLoggingModeAppend, buf);
	}

// set the controls in the main interface.
void CTxtViewerAppView::InitializeControlsL( const TRect& aRect )
	{
	// define the label and text field in the interface.
	iTypeLabel = new ( ELeave ) CEikLabel;
	iTypeLabel->SetContainerWindowL( *this );
		{
		TResourceReader reader;
		iEikonEnv->CreateResourceReaderLC( reader, R_TEST_PROJECT1_CONTAINER_TYPE_LABEL );
		iTypeLabel->ConstructFromResourceL( reader );
		CleanupStack::PopAndDestroy(); // reader internal state
		}
	iTagLabel = new ( ELeave ) CEikLabel;
	iTagLabel->SetContainerWindowL( *this );
		{
		TResourceReader reader;
		iEikonEnv->CreateResourceReaderLC( reader, R_TEST_PROJECT1_CONTAINER_TAG_LABEL );
		iTagLabel->ConstructFromResourceL( reader );
		CleanupStack::PopAndDestroy(); // reader internal state
		}
	iTypeText = new ( ELeave ) CEikEdwin;
	iTypeText->SetContainerWindowL( *this );
		{
		TResourceReader reader;
		iEikonEnv->CreateResourceReaderLC( reader, R_TEST_PROJECT1_CONTAINER_TYPE_TEXT );
		iTypeText->ConstructFromResourceL( reader );
		CleanupStack::PopAndDestroy(); // reader internal state
		}
		{
		HBufC* text = StringLoader::LoadLC( R_TEST_PROJECT1_CONTAINER_TYPE_TEXT_2 );
		iTypeText->SetTextL( text );
		CleanupStack::PopAndDestroy( text );
		}
	iTagsText = new ( ELeave ) CEikEdwin;
	iTagsText->SetContainerWindowL( *this );
		{
		TResourceReader reader;
		iEikonEnv->CreateResourceReaderLC( reader, R_TEST_PROJECT1_CONTAINER_TAGS_TEXT );
		iTagsText->ConstructFromResourceL( reader );
		CleanupStack::PopAndDestroy(); // reader internal state
		}
		{
		HBufC* text = StringLoader::LoadLC( R_TEST_PROJECT1_CONTAINER_TAGS_TEXT_2 );
		iTagsText->SetTextL( text );
		CleanupStack::PopAndDestroy( text );
		}
	iEditor = new ( ELeave ) CEikRichTextEditor;
	iEditor->SetContainerWindowL ( *this);
		{
		TResourceReader reader;
		iEikonEnv->CreateResourceReaderLC( reader, R_TEST_PROJECT1_CONTAINER_DESCRIPTION_TEXT );
		iEditor->ConstructFromResourceL ( reader);
		CleanupStack::PopAndDestroy (); // reader internal state
		}
		{
		HBufC* text = StringLoader::LoadLC ( R_TEST_PROJECT1_CONTAINER_DESCRIPTION_TEXT_2);
		iEditor->SetTextL ( text);
		CleanupStack::PopAndDestroy ( text);
		}
	TBool edit = OpenedForEditing();
	

	TInt editorflags(0);	
		
//	if (edit) 
		{
		editorflags=0;			
		}
//	else 
//		{
//		editorflags=EEikEdwinReadOnly;
//		}
//	iEditor->ConstructL ( this, KNumberOfLines, KTextLimit, editorflags,
//			EGulFontControlAll, EGulNoSymbolFonts);

	// Create a scrollbar for it
	iEditor->CreateScrollBarFrameL()->SetScrollBarVisibilityL ( CEikScrollBarFrame::EOff,
			CEikScrollBarFrame::EOn);

	iFocusControls[0]=iTypeText;
	iFocusControls[1]=iTagsText;
	iFocusControls[2]=iEditor;
	iCurrentFocusIdx = 0;
	iFocusControls[iCurrentFocusIdx]->SetFocus ( ETrue);

	iTypeLabel->SetRect( TRect(TPoint(0,0), TSize( 68, 27 )));
	iTagLabel->SetRect( TRect(TPoint( 0, 30 ), TSize( 67, 27 )) );
	iTypeText->SetRect( TRect(TPoint( 80, 7 ), TSize( 150, 20 )) );
	iTagsText->SetRect( TRect(TPoint( 80, 37 ), TSize( 150, 20 )) );
	iEditor->SetRect( TRect(TPoint( 0, 65 ), TSize( 242, 162 )) );

	}

/**
* Return the number of controls in the container (override)
* @return count
*/
TInt CTxtViewerAppView::CountComponentControls() const
	{
	return ( int ) ELastControl;
	}
				
/**
* Get the control with the given index (override)
* @param aIndex Control index [0...n) (limited by #CountComponentControls)
* @return Pointer to control
*/
CCoeControl* CTxtViewerAppView::ComponentControl( TInt aIndex ) const
	{
	// [[[ begin generated region: do not modify [Generated Contents]
	switch ( aIndex )
		{
		case ETypeLabel:
			return iTypeLabel;
		case ETagLabel:
			return iTagLabel;
		case ETypeText:
			return iTypeText;
		case ETagsText:
			return iTagsText;
		case EDescriptionText:
			return iEditor;
		}
	// ]]] end generated region [Generated Contents]
	
	// handle any user controls here...
	
	return NULL;
	}


void CTxtViewerAppView::Notify()
	{
			// Change CBA if we are not editing 
	CEikButtonGroupContainer* container = iEikonEnv->AppUiFactory()->Cba();	
	if (!OpenedForEditing())
		{
		container->SetCommandSetL(R_AVKON_SOFTKEYS_BACK);
		}
	else 
		{
		container->SetCommandSetL(R_AVKON_SOFTKEYS_OPTIONS_BACK);
		}

	container->DrawDeferred();

	// Initialize component array
	InitComponentArrayL(); 		// call once

	TRect rect;
	AknLayoutUtils::LayoutMetricsRect( AknLayoutUtils::EMainPane, rect );

    // Set the windows size
    SetRect(rect);
    // Activate the window, which makes it ready to be drawn
    ActivateL();
//    this->DeactivateGc();
	InitializeMTMsL();
	LoadBodyL();
	}
// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CTxtViewerAppView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CTxtViewerAppView* CTxtViewerAppView::NewL( const TRect& aRect )
    {
    CTxtViewerAppView* self = CTxtViewerAppView::NewLC( aRect );
    CleanupStack::Pop( self );
    return self;
    }

// -----------------------------------------------------------------------------
// CTxtViewerAppView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CTxtViewerAppView* CTxtViewerAppView::NewLC( const TRect& aRect )
    {
    CTxtViewerAppView* self = new ( ELeave ) CTxtViewerAppView;
    CleanupStack::PushL( self );
    self->ConstructL( aRect );
    return self;
    }

// -----------------------------------------------------------------------------
// CTxtViewerAppView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CTxtViewerAppView::ConstructL( const TRect& aRect )
    {
	// Create a window for this application view
    CreateWindowL ();
    TBuf<256> filename;
    filename.Append(KTextMTMTagsFile);
    this->iTagTable=TTagTable::CreateTagTableL(filename , MAX_TAG_TABLE);
    if(iTagTable == NULL){
    	iTagTable=TTagTable::CreateDummyTagTableL();
    	writeLog(_L("a dummy tag table is created"));
    }
	InitializeControlsL(aRect);
    }

// the length of the string I need to delete in the rich text.
// actually, it's the length of the string before the description.
TInt DeleteLen(CRichText *text)
	{
	TBuf<BUF_SIZE> tmpBuf16;
	text->Extract (tmpBuf16, 0, 127);
	TLex lex(tmpBuf16);
	int deleteLen=0;
	int numOfSemicomma=0;
	while (1)
		{
		if ( lex.Peek ()== ';')
			numOfSemicomma++;
		if ( lex.Peek ()== 0)
			break;
		deleteLen++;
		lex.Inc ();
		if ( numOfSemicomma == 3)
			break;
		}
	return deleteLen;
	}

// -----------------------------------------------------------------------------
// CTxtViewerAppView::LoadBodyL()
// Load message body to the editor.
// -----------------------------------------------------------------------------
//
void CTxtViewerAppView::LoadBodyL()
	{
	TMsvId id= EntryId();
	
	// Switch context 
	iClientMtm->SwitchCurrentEntryL(id);
		
	// Set state to editing
	iStore=iClientMtm->Entry().EditStoreL();

	// Get editor's CRichBox object
    CRichText* body = iEditor->RichText();
    
	// Restore CRichText to body
	iStore->RestoreBodyTextL(*body);
	
	// the text in the message is unicode.
	// so I need to convert the string.
    TBuf8<BUF_SIZE> tmpBuf8;
		{
		TBuf<BUF_SIZE> tmpBuf16;
		body->Extract (tmpBuf16, 0, BUF_SIZE);
		writeLog(tmpBuf16);
		tmpBuf8.Copy (tmpBuf16);
		}
    CArrayFixFlat<TInt>* tagIDs = new CArrayFixFlat<TInt>(MAX_TAGS);
    CleanupStack::PushL (tagIDs);
	TInt msgType=-1;

    // skip the msg ID
	writeLog(_L("before skip the msg ID"));
    TInt len=tmpBuf8.FindC ((const unsigned char *)";", 1);
	if ( len == KErrNotFound)
		goto display;
	tmpBuf8.Delete(0 , len+1);
	writeLog(_L("before getting the message type"));
	// get the msg type
		{
		TBuf8<BUF_SIZE> tmp;
		len=tmpBuf8.FindC ((const unsigned char *)";", 1);
		if ( len == KErrNotFound)
			goto display;
		tmp=tmpBuf8.MidTPtr (0, len);
		TLex8 lex(tmp);
		TInt val;
		if ( lex.Val (val)!= KErrNone)
			goto display;
		msgType=val;
		}
	tmpBuf8.Delete(0 , len+1);
	// get the tag IDs
	for (int i=0; i < MAX_TAGS; i++)
		{
		// tag IDs are separated by ','
		len=tmpBuf8.FindC ((const unsigned char *)",", 1);
		if ( len == KErrNotFound)
			{
			// try to read the last msg ID
			len=tmpBuf8.FindC ((const unsigned char *)";", 1);
			if ( len == KErrNotFound)
				{
				goto display;
				}
			// get the index of the tag in the tag table.
			TInt idx=iTagTable->GetIdx(iTagTable->GetTagByID(tmpBuf8.MidTPtr(0 , len)));
			tmpBuf8.Delete(0 , len+1);
			if(idx < 0)
				goto display;
			tagIDs->AppendL (idx);
			break;
			}
		TInt idx=iTagTable->GetIdx(iTagTable->GetTagByID(tmpBuf8.MidTPtr(0 , len)));
		if(idx < 0)
			goto display;
		tagIDs->AppendL(idx);
		tmpBuf8.Delete(0 , len+1);
		}
display:
	if ( msgType >= 0)
			SetTypeText (msgType);
	if(tagIDs->Count() > 0)
		SetTagsText(tagIDs , &iTagIDs);
	CleanupStack::PopAndDestroy(tagIDs);
	
	body->DeleteL(0 , DeleteLen(body));
	
	delete iStore;
	iStore = NULL;
	    
    iEditor->HandleTextChangedL();
	}
// -----------------------------------------------------------------------------
// CTxtViewerAppView::SaveBodyL()
// Saves message body to the stream.
// -----------------------------------------------------------------------------
//
// this function is called when the message is stored in the draft box or is sent (stored in a specific file)
void CTxtViewerAppView::SaveBodyL()
	{
	TMsvId id= EntryId();

	// Switch context 
	iClientMtm->SwitchCurrentEntryL(id);
		
	// Set state to editing
	iStore=iClientMtm->Entry().EditStoreL();

	// Get editor's CRichBox object
	// it only contains the description of the message.
    CRichText* text = iEditor->RichText();
    // add the type and tags into the message.
    TBuf<BUF_SIZE> tmpBuf16;
    // The MTM message must start with the length of the message
    tmpBuf16.Append(4+iTagIDs.Length()+1);
    tmpBuf16.Append('0');
    tmpBuf16.Append(';');
    tmpBuf16.Append(iMsgType+'0');
    tmpBuf16.Append (';');
		{
		TBuf<BUF_SIZE> tmp;
		tmp.Copy (iTagIDs);
		tmpBuf16.Append (tmp);
		}
    tmpBuf16.Append(';');
    
    text->InsertL(0 , tmpBuf16);
	// Store CRichText in body
	iStore->StoreBodyTextL(*text);

	iStore->CommitL();
	
	delete iStore;

	iStore=NULL;
	}

// -----------------------------------------------------------------------------
// CTxtViewerAppView::CTxtViewerAppView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CTxtViewerAppView::CTxtViewerAppView()
    {
    for(int i=0 ; i < FOCUSCONTROLNUM ; i++)
    	iFocusControls[i]=NULL;
	iTypeListBox = NULL;
	iTagsListBox = NULL;
	
	iTagTable=NULL;
	iMsgType=0;
    }


// -----------------------------------------------------------------------------
// CTxtViewerAppView::OfferKeyEventL
// Pass key events to the editor
// this key handler must handle events for all controls in its interface
// and two list boxes.
// -----------------------------------------------------------------------------
//
TKeyResponse CTxtViewerAppView::OfferKeyEventL(const TKeyEvent& aKeyEvent,
		TEventCode aType)
	{
	TRect rect;
	if ( iTypeListBox)
		{
		iTypeListBox->OfferKeyEventL (aKeyEvent, aType);
		if ( aKeyEvent.iCode == 63557)// if the enter key is pressed.
			this->GetSelectedTypeItemL ();
		return EKeyWasConsumed;
		}
	if ( iTagsListBox)
		return iTagsListBox->OfferKeyEventL (aKeyEvent, aType);
	
	// now we are handling the key events for the conrols in the interface.
	if ( aKeyEvent.iCode == 63557)
		{
		AknLayoutUtils::LayoutMetricsRect ( AknLayoutUtils::EMainPane, rect);
		// if we are focusing on the type editor, display the type selection list box.
		if ( iCurrentFocusIdx == 0)
			{
			iTypeListBox=CTxtViewerTypeList::NewL (rect, this);
			// the type selection list box is displayed, we can only allow the back command
			iEikonEnv->AppUiFactory()->Cba()->SetCommandSetL(R_AVKON_SOFTKEYS_BACK);
			iEikonEnv->AppUiFactory()->Cba()->DrawNow();
			}
		// if we are on the tag editor, display the tag selection list.
		if ( iCurrentFocusIdx == 1)
			{
			iTagsListBox=CTxtViewerTagsList::NewL (rect, this);
			// the tag selection list box is displayed, we can only allow the OK and cancel command.
			iEikonEnv->AppUiFactory()->Cba()->SetCommandSetL(R_AVKON_SOFTKEYS_OK_CANCEL);
			iEikonEnv->AppUiFactory()->Cba()->DrawNow();
			writeLog(_L("the tag list is displayed"));
			}
		return EKeyWasConsumed;
		}

	if ( MoveFocusControl (aKeyEvent, aType))
		return EKeyWasConsumed;

	// handle the rest key event.
	if ( iFocusControls[iCurrentFocusIdx]&& iFocusControls[iCurrentFocusIdx]->OfferKeyEventL (
			aKeyEvent, aType)== EKeyWasConsumed)
		{
		return EKeyWasConsumed;
		}
	return CCoeControl::OfferKeyEventL ( aKeyEvent, aType);
	}

// this function hanlde the key event of up arrow and down arrow.
// so we can focus on different control in the interface.
int CTxtViewerAppView::MoveFocusControl(const TKeyEvent& aKeyEvent , TEventCode aType)
	{
	if(aKeyEvent.iCode != EKeyUpArrow && aKeyEvent.iCode != EKeyDownArrow)
		return 0;
	if(iCurrentFocusIdx == 0 && aKeyEvent.iCode == EKeyUpArrow)
		return 0;
	if(iCurrentFocusIdx == FOCUSCONTROLNUM-1 && aKeyEvent.iCode == EKeyDownArrow)
		return 0;

	iFocusControls[iCurrentFocusIdx]->SetFocus ( EFalse);
	switch (aKeyEvent.iCode)
		{
		case EKeyDownArrow:
			iCurrentFocusIdx++;
			break;
		case EKeyUpArrow:
			// TODO If it focuses on rich text editor, 
			// I need to handle the key event only when the current cursor is in its first line.
			iCurrentFocusIdx--;
			break;
		}
	iFocusControls[iCurrentFocusIdx]->SetFocus ( ETrue);
	return 1;
	}


TMsvId CTxtViewerAppView::EntryId() 
	{
	
	// Get Id from the document
	CEikonEnv* env = CEikonEnv::Static();
	
	CTxtViewerAppUi* appui = static_cast<CTxtViewerAppUi*>(env->AppUi());
	
	CTxtViewerDocument* doc = appui->Document();
	
	return doc->Id();
	
	}
	
TBool CTxtViewerAppView::OpenedForEditing() 
	{
	// Get Id from the document
	CEikonEnv* env = CEikonEnv::Static();
	
	CTxtViewerAppUi* appui = static_cast<CTxtViewerAppUi*>(env->AppUi());
	
	CTxtViewerDocument* doc = appui->Document();
	
	return doc->OpenedForEditing();
		
	}
		

void CTxtViewerAppView::InitializeMTMsL()
	{
	// Create a session to the message server
	iSession = CMsvSession::OpenSyncL(iOb);
	//CleanupStack::PushL(session);

	// Get ui and client registries
	iClientReg = CClientMtmRegistry::NewL(*iSession);	
	
	iUiReg = CMtmUiRegistry::NewL(*iSession);	

	// Check if that type is available otherwise leave
	if(!iClientReg->IsPresent(KUidMsgTypeText))	User::Leave(KErrNotFound);
	
	// try to create ui mtm and client mtm instances
	iClientMtm = (CTextMtmClient*)iClientReg->NewMtmL(KUidMsgTypeText);
	
	iUiMtm = (CTextMtmUi*)iUiReg->NewMtmUiL(*iClientMtm );
	
	TMsvId id= EntryId();
	
	// Switch context 
	iClientMtm->SwitchCurrentEntryL(id);
		
	// Set state to editing
	iStore=iClientMtm->Entry().EditStoreL();
	
	
	// Create a body for the message if body is missing
	if (!iStore->HasBodyTextL())
		{
		// Create CRichText object
		CRichText* body = CRichText::NewL(iEikonEnv->SystemParaFormatLayerL(), 
			iEikonEnv->SystemCharFormatLayerL());
		CleanupStack::PushL(body);

		// Store CRichText in body
		iStore->StoreBodyTextL(*body);
		iStore->CommitL();
	
		CleanupStack::PopAndDestroy(); // body
		}

	delete iStore;
	iStore=NULL;
	}

// -----------------------------------------------------------------------------
// CTxtViewerAppView::~CTxtViewerAppView()
// Destructor.
// -----------------------------------------------------------------------------
//
CTxtViewerAppView::~CTxtViewerAppView()
    {
	delete iStore;
	delete iClientMtm; 
	delete iUiMtm;
  	delete iUiReg;
  	delete iClientReg; 
   	delete iSession;
   	
   	delete iEditor;
	delete iTypeLabel;
	iTypeLabel = NULL;
	delete iTagLabel;
	iTagLabel = NULL;
	delete iTypeText;
	iTypeText = NULL;
	delete iTagsText;
	iTagsText = NULL;
	
	if(iTypeListBox)
		delete iTypeListBox;
	if(iTagsListBox)
		delete iTagsListBox;
	if(iTagTable)
		delete iTagTable;
    }

// -----------------------------------------------------------------------------
// CTxtViewerAppView::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
//
void CTxtViewerAppView::Draw( const TRect& aRect ) const
    {
	CWindowGc& gc = SystemGc();
	TRgb bg_color = TRgb(211 , 211 , 211 , 255) ;
	gc.SetBrushColor(bg_color);
	gc.Clear(aRect);

  	}

// -----------------------------------------------------------------------------
// CTxtViewerAppView::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void CTxtViewerAppView::SizeChanged()
    {  
    TRect rect;
	
	AknLayoutUtils::LayoutMetricsRect( AknLayoutUtils::EMainPane, rect );

	iTypeLabel->SetRect( TRect(TPoint(0,0), TSize( 68, 27 )));
	iTagLabel->SetRect( TRect(TPoint( 0, 30 ), TSize( 67, 27 )) );
	iTypeText->SetRect( TRect(TPoint( 80, 7 ), TSize( 150, 20 )) );
	iTagsText->SetRect( TRect(TPoint( 80, 37 ), TSize( 150, 20 )) );
	iEditor->SetRect( TRect(TPoint( 0, 65 ), TSize( 242, 162 )) );
    
    DrawNow();
    }

// this function save the message into the file.
// it is called when the message is sent out.
void CTxtViewerAppView::ExportToFileL( const TDes& aFileName )
    {
    RFileWriteStream myFileWriteStream;
    
    myFileWriteStream.Open(  CCoeEnv::Static()->FsSession(), aFileName , EFileWrite );

    myFileWriteStream.PushL();

    // Get editor's CRichBox object
    CGlobalText* text = iEditor->GlobalText();

    text->ExternalizePlainTextNoLengthCountL( myFileWriteStream );

    myFileWriteStream.CommitL();

    myFileWriteStream.Close();

    myFileWriteStream.Pop();
    }

// display the tag names in the tag editor,
// and save its tag IDs.
void CTxtViewerAppView::SetTagsText(const CArrayFix<TInt> *indexes , TDes8 *retTagsIDs)
	{
	TBuf <BUF_SIZE> aString;
	// loop through the selected item indexes
	TBuf8 <BUF_SIZE> tagIDs;
	for (TInt idx=0; idx < indexes->Count (); idx++)
		{
		// get the index of the selected item
		TInt itemIndex = indexes->At(idx);
		TBuf <BUF_SIZE> tmpStr;
//		TPtrC8 tmpStr8();
		tmpStr.Copy(*iTagTable->GetTagByPos(itemIndex)->name);
		aString.Append(tmpStr);
		tagIDs.Append(*iTagTable->GetTagByPos(itemIndex)->id);
		if ( idx != indexes->Count ()-1)
			{
			aString.Append (',');
			tagIDs.Append(',');
			}
		}
	iTagsText->SetTextL(&aString);
	if(retTagsIDs)
		*retTagsIDs=tagIDs;
	
	}

void CTxtViewerAppView::GetSelectedTagItemsL(int ok)
	{
	if ( ok)
		{
		const CArrayFix<TInt> *indexes = iTagsListBox->GetSelectedItemsL ();
		if ( indexes!=NULL)
			{
			SetTagsText (indexes, &iTagIDs);
			}
		}
	CloseSelectionList();
	}

void CTxtViewerAppView::SetTypeText(int pos)
	{
	if(pos)
		{
		HBufC* text = StringLoader::LoadLC( R_OFINE_OFFER );
		iTypeText->SetTextL( text );
		CleanupStack::PopAndDestroy( text );
		iMsgType=1;
		}
	else
		{
		HBufC* text = StringLoader::LoadLC( R_OFINE_NEED );
		iTypeText->SetTextL( text );
		CleanupStack::PopAndDestroy( text );
		iMsgType=0;
		}
	}

void CTxtViewerAppView::GetSelectedTypeItemL()
	{
	int pos=iTypeListBox->iCurrPos;
	iMsgType=pos;
	SetTypeText(pos);
	
	CloseSelectionList();
	}

// close the selection list,
// and display the origianl interface.
bool CTxtViewerAppView::CloseSelectionList()
	{
	if ( iTypeListBox)
		{
		delete iTypeListBox;
		iTypeListBox=NULL;
		iEikonEnv->AppUiFactory()->Cba()->SetCommandSetL(R_AVKON_SOFTKEYS_OPTIONS_BACK);
		iEikonEnv->AppUiFactory()->Cba()->DrawNow();
		DrawNow();
		return true;
		}
	else
		if ( iTagsListBox)
			{
			delete iTagsListBox;
			iTagsListBox=NULL;
			iEikonEnv->AppUiFactory()->Cba()->SetCommandSetL(R_AVKON_SOFTKEYS_OPTIONS_BACK);
			iEikonEnv->AppUiFactory()->Cba()->DrawNow();
			return true;
			}
	return false;
	}

// End of File
