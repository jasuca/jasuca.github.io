
// INCLUDE FILES
#include <msvapi.h>             // CMsvOperation, CMsvEntry
#include <msvuids.h>            // Msgs Uids
#include "txtviewerdoc.h"    // CTxtViewerDocument
#include "txtviewerappui.h"  // CTxtViewerAppUi
#include "txtviewerappview.h"
// ================= MEMBER FUNCTIONS =======================

// C++ constructor can NOT contain any code, that
// might leave.
//
CTxtViewerDocument::CTxtViewerDocument( 
    CEikApplication& aApp): CEikDocument(aApp)
        
    {
    }
   

void CTxtViewerDocument::ConstructL()
    {
    // No implementation required
    }

// Two-phased constructor.
CTxtViewerDocument* CTxtViewerDocument::NewL(
    CEikApplication& aApp)
    {
    CTxtViewerDocument* sed = new (ELeave) CTxtViewerDocument(aApp);
    CleanupStack::PushL(sed);
    sed->ConstructL();
    CleanupStack::Pop();
    return sed;
    }
    
// Destructor
CTxtViewerDocument::~CTxtViewerDocument()
    {
    }

// ---------------------------------------------------------
// CTxtViewerDocument::CreateAppUiL
// (other items were commented in a header).
// ---------------------------------------------------------
CEikAppUi* CTxtViewerDocument::CreateAppUiL()
    {
    return new ( ELeave ) CTxtViewerAppUi;
    }

void CTxtViewerDocument::SetId(TMsvId aId)
    {
	iId = aId;
              
    }

TMsvId CTxtViewerDocument::Id()
    {
    return iId;
    }



void CTxtViewerDocument::SetOpenedForEditing(TBool aOpenedForEditing)
	{
	iOpenedForEditing=aOpenedForEditing;
	}
TBool CTxtViewerDocument::OpenedForEditing()
	{
	return iOpenedForEditing;		
	}

void CTxtViewerDocument::SetMessage(const RMessage2 aMessage)
	{
	iMessage=aMessage;		
	}
RMessage2 CTxtViewerDocument::Message()
	{
	return iMessage;
	}

void CTxtViewerDocument::InitializeL() 
	{


	iAppView->Notify();
	}
void CTxtViewerDocument::SetView(CTxtViewerAppView* aView) 
	{
	iAppView = aView;
	}
	
