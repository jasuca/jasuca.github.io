// INCLUDE FILES
#include <coemain.h>
#include <EIKENV.H> 

#include <eikdef.h>
#include <coeaui.h>
#include "txtviewerdoc.h"
#include "EIKAPPUI.H"
#include <aknutils.h> //LayoutUtils
#include <eiktxlbx.h> 
#include <akniconarray.h> 
#include <gulicon.h>
#include <eikclbd.h>
#include <avkon.mbg>
#include <stringloader.h>

#include "TxtViewerAppView.h"

//Messaging related

#include <mtclreg.h>
#include <mtuireg.h>
#include <MTUDREG.H> 
#include <MTUIREG.H> 
#include <msvids.h>
#include <TXTRICH.H>
#include <eiklabel.h>
#include <BARSREAD.H>
#include <stringloader.h> 
#include <TxtViewer.RSG>
#include <flogger.h>
#include <VERSIT.H>

#include <MTCLBASE.H> // SwitchCurrentEntryL

static void writeLog(TRefByValue<const TDesC16> aFmt,...)
	{
#define KMaxFileName 128
	VA_LIST list;
	VA_START(list,aFmt);

	TBuf<KMaxFileName> buf;
	buf.AppendFormatList(aFmt,list);
	VA_END(list);

	RFileLogger::Write(_L ("log"), _L ("testlog"), EFileLoggingModeAppend, buf);
	}


CTxtViewerTypeList* CTxtViewerTypeList::NewL(const TRect& aRect , CCoeControl *father)
	{
	CTxtViewerTypeList* me = new (ELeave) CTxtViewerTypeList(father);
	CleanupStack::PushL(me);
	me->ConstructL(aRect);
	CleanupStack::Pop(me);
	return (me);
	}

CTxtViewerTypeList::CTxtViewerTypeList(CCoeControl *father):iFather(father)
	{}

CTxtViewerTypeList::~CTxtViewerTypeList()
	{
	iFocusPos.Close();
	delete iListBox;
	}

void CTxtViewerTypeList::ConstructL(const TRect& aRect)
	{
	CreateWindowL(iFather);
	
    iListBox = new (ELeave) CAknSingleStyleListBox  (); 
    iListBox->ConstructL(this, EAknListBoxSelectionList);
	iListBox->SetContainerWindowL(*this);
	iListBox->SetListBoxObserver(this);
	
	SetupListTextL();

	SetRect(aRect);
	ActivateL();
    DrawNow();
	}

void CTxtViewerTypeList::SetupListTextL()
	{
	// Get the list box model
	CTextListBoxModel* model = iListBox->Model();    // Does not own the returned model
	User::LeaveIfNull(model);
	model->SetOwnershipType(ELbmOwnsItemArray);
	
	CDesCArray* itemArray = static_cast<CDesCArray*>(model->ItemTextArray());
	User::LeaveIfNull(itemArray);
	
	itemArray->Reset(); //  Remove content from the array

	itemArray->AppendL(_L("\tNeed"));
	iListBox->HandleItemAdditionL();

    itemArray->AppendL(_L("\tOffer"));
	iListBox->HandleItemAdditionL();
    iListBox->SetCurrentItemIndex(0);
    
	iCurrPos = ENEED;	
	}

void CTxtViewerTypeList::HandleListBoxEventL(CEikListBox* /*aListBox*/, TListBoxEvent aEventType)
	{
	switch(aEventType)
		{
		case EEventEnterKeyPressed:
		case EEventItemClicked:
			iCurrPos=iListBox->CurrentItemIndex();
		    break;
        default: // Nothing to do
		    break;
    };
  }


TKeyResponse CTxtViewerTypeList::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
	{
	return (iListBox->OfferKeyEventL(aKeyEvent, aType));
	}
	

void CTxtViewerTypeList::Draw(const TRect& aRect) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear(aRect);
	}


void CTxtViewerTypeList::SizeChanged()
	{
	const TPoint listPosition(0,0);
	iListBox->SetExtent(listPosition, iListBox->MinimumSize());
	}

TInt CTxtViewerTypeList::CountComponentControls() const
	{
	return (1);
	}

CCoeControl* CTxtViewerTypeList::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return (iListBox);
		default:
			return (NULL);
		}
	}

CTxtViewerTagsList* CTxtViewerTagsList::NewL(const TRect& aRect , CCoeControl *father)
	{
	CTxtViewerTagsList* me = new (ELeave) CTxtViewerTagsList(father);
	CleanupStack::PushL(me);
	me->ConstructL(aRect);
	CleanupStack::Pop(me);
	return (me);
	}

CTxtViewerTagsList::CTxtViewerTagsList(CCoeControl *father):iFather(father)
	{
	}

CTxtViewerTagsList::~CTxtViewerTagsList()
	{
	iFocusPos.Close();
	delete iListBox;
	}

void CTxtViewerTagsList::ConstructL(const TRect& aRect)
	{
	CreateWindowL();
	
    iListBox = new (ELeave) CAknSingleStyleListBox  (); 
    iListBox->ConstructL(this, EAknListBoxMultiselectionList);
	iListBox->SetContainerWindowL(*this);
	iListBox->SetListBoxObserver(this);
	iListBox->CreateScrollBarFrameL(ETrue);
	iListBox->ScrollBarFrame() ->SetScrollBarVisibilityL(
			   CEikScrollBarFrame::EOff, CEikScrollBarFrame::EAuto);
	
	SetupListTextL();
	SetupListIconsL();
	SetRect(aRect);
	ActivateL();
    DrawNow();
	}

CGulIcon *CreateCheckBoxIcon(TInt aBitmapId, TInt aMaskId)
	{
	CFbsBitmap* lBitmapMarked=  NULL;
	CFbsBitmap* lBitmapMarkedMask=  NULL;

	AknIconUtils::CreateIconLC (lBitmapMarked, lBitmapMarkedMask,
			AknIconUtils::AvkonIconFileName (), aBitmapId, aMaskId);

	CGulIcon* lIconMarked = CGulIcon::NewL (lBitmapMarked, lBitmapMarkedMask);

	CleanupStack::Pop (2); // lBitmapMarked, lBitmapMarkedMask
	return lIconMarked;
	}

void CTxtViewerTagsList::SetupListIconsL()
	{
	const TInt KNumberOfIcons=3;
	CArrayPtr<CGulIcon>* icons = new(ELeave)CAknIconArray(KNumberOfIcons);

	CleanupStack::PushL (icons);
	CGulIcon *icon=CreateCheckBoxIcon(EMbmAvkonQgn_prop_checkbox_on,EMbmAvkonQgn_prop_checkbox_on_mask);
	CleanupStack::PushL(icon);
	icons->AppendL (icon);
	CleanupStack::Pop(icon);
	icon=CreateCheckBoxIcon(EMbmAvkonQgn_prop_checkbox_off,EMbmAvkonQgn_prop_checkbox_off_mask);
	CleanupStack::PushL(icon);
	icons->AppendL (icon);
	CleanupStack::Pop(icon);
	icon=CreateCheckBoxIcon(EMbmAvkonQgn_prop_checkbox_off,EMbmAvkonQgn_prop_checkbox_off_mask);
	CleanupStack::PushL(icon);
	icons->AppendL (icon);
	CleanupStack::Pop(icon);

	CleanupStack::Pop (icons);
	iListBox->ItemDrawer()->ColumnData()->SetIconArray (icons);
	}

void CTxtViewerTagsList::SetupListTextL()
	{
	// Get the list box model
	CTextListBoxModel* model = iListBox->Model();    // Does not own the returned model
	User::LeaveIfNull(model);
	model->SetOwnershipType(ELbmOwnsItemArray);
	
	CDesCArray* itemArray = static_cast<CDesCArray*>(model->ItemTextArray());
	User::LeaveIfNull (itemArray);

	itemArray->Reset (); //  Remove content from the array

	TInt i=0;
	TagStruct *tag;
	while((tag=((CTxtViewerAppView *)iFather)->iTagTable->GetTagByPos(i)))
		{
		TBuf<BUF_SIZE> tmp;
		tmp.Append (_L("1\t"));
		TBuf<BUF_SIZE> tmp16;
		tmp16.Copy(*tag->name);
		tmp.Append (tmp16);
		itemArray->AppendL(tmp);
		iListBox->HandleItemAdditionL ();
		i++;
		}
	iListBox->SetCurrentItemIndex (0);
    
	iCurrPos = 0;	
	}

void CTxtViewerTagsList::HandleListBoxEventL(CEikListBox* /*aListBox*/, TListBoxEvent aEventType)
	{
	switch(aEventType)
		{
		case EEventEnterKeyPressed:
		case EEventItemClicked:
			this->CloseWindow();
		    break;
        default: // Nothing to do
		    break;
    };
  }


TKeyResponse CTxtViewerTagsList::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
	{
	return (iListBox->OfferKeyEventL(aKeyEvent, aType));
	}
	

void CTxtViewerTagsList::Draw(const TRect& aRect) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear(aRect);
	}

void CTxtViewerTagsList::SizeChanged()
	{
	const TPoint listPosition(0,0);
	iListBox->SetExtent(listPosition, iListBox->MinimumSize());
	}

TInt CTxtViewerTagsList::CountComponentControls() const
	{
	return (1); // return number of controls inside this container
	}

CCoeControl* CTxtViewerTagsList::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return (iListBox);
		default:
			return (NULL);
		}
	}

// get all selected items
const CArrayFix<TInt> *CTxtViewerTagsList::GetSelectedItemsL()
{
	return iListBox->SelectionIndexes();//->View()->GetSelectionIndexesL(&aSelectionArray);
}
